﻿using Microsoft.AspNetCore.Mvc;
using taskforge.Data.Models.DTO;
using taskforge.Services;

namespace taskforge.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CompilerController : ControllerBase
    {
        private readonly CompilerService _svc;

        public CompilerController(CompilerService svc)
        {
            _svc = svc;
        }

        [HttpPost("run")]
        public async Task<IActionResult> Run([FromBody] CompilerRunRequestDto req)
        {
            var r = await _svc.RunAsync(req);

            // Для удобства фронта можно всегда отдавать 200 и статус внутри JSON,
            // но если хочешь — можно подсветить 400 на компиляции:
            if (r.Status == "compile_error") return BadRequest(r);

            return Ok(r);
        }

        [HttpPost("run-tests")]
        public async Task<IActionResult> RunTests([FromBody] TestRunRequestDto req)
        {
            var list = await _svc.RunTestsAsync(req);
            return Ok(new { results = list });
        }
    }
}
