﻿using Microsoft.Extensions.Configuration;
using taskforge.Services.Interfaces;

namespace taskforge.Services
{
    public sealed class CSharpCompiler : HttpRunnerCompilerBase, ICompiler
    {
        private readonly string _baseUrl;

        public CSharpCompiler(IHttpClientFactory http, IConfiguration cfg)
            : base(http, cfg, "csharp")
        {
            _baseUrl = cfg["Compilers:csharp:Url"]
                    ?? cfg["Compilers__csharp__Url"]
                    ?? "http://csharp-runner:8080";
        }

        protected override string BaseUrl => _baseUrl;
    }
}
