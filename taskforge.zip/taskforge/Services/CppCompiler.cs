﻿using Microsoft.Extensions.Configuration;
using taskforge.Services.Interfaces;

namespace taskforge.Services
{
    public sealed class CppCompiler : HttpRunnerCompilerBase, ICompiler
    {
        private readonly string _baseUrl;

        public CppCompiler(IHttpClientFactory http, IConfiguration cfg)
            : base(http, cfg, "cpp")
        {
            _baseUrl = cfg["Compilers:cpp:Url"]
                    ?? cfg["Compilers__cpp__Url"]
                    ?? "http://cpp-runner:8080";
        }

        protected override string BaseUrl => _baseUrl;
    }
}
