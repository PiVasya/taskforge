﻿using taskforge.Data.Models.DTO;
using taskforge.Services.Interfaces;

namespace taskforge.Services
{
    public class CompilerService
    {
        private readonly ICompiler _compiler;

        public CompilerService(ICompiler compiler)
        {
            _compiler = compiler;
        }

        public async Task<CompilerRunResponseDto> RunAsync(CompilerRunRequestDto req)
        {
            // Просто проксируем к конкретному раннеру
            var run = await _compiler.CompileAndRunAsync(req);

            // (опционально) подровнять сообщение для UI
            if (run.Status == "compile_error" && string.IsNullOrEmpty(run.Message))
                run.Message = "Ошибка компиляции";
            else if (run.Status == "runtime_error" && string.IsNullOrEmpty(run.Message))
                run.Message = "Ошибка во время выполнения";
            else if (run.Status == "time_limit" && string.IsNullOrEmpty(run.Message))
                run.Message = "Превышен лимит времени";

            return run;
        }

        public async Task<IList<TestResultDto>> RunTestsAsync(TestRunRequestDto req)
        {
            return await _compiler.RunTestsAsync(
                req.Code,
                req.TestCases ?? new List<TestCaseDto>(),
                req.TimeLimitMs,
                req.MemoryLimitMb
            );
        }
    }
}
