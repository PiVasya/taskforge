using System.Net.Http.Json;
using taskforge.Data.Models.DTO;
using taskforge.Services.Interfaces;

namespace taskforge.Services.Remote
{
    /// <summary>
    /// Базовый HTTP-клиент для языковых раннеров (CPP/C#/Python).
    /// Ожидает новый контракт раннера:
    /// { status, exitCode, stdout, stderr, compileStderr } и
    /// для тестов: { results: [ { ... те же поля ..., passed } ] }.
    /// </summary>
    public abstract class HttpRunnerCompilerBase : ICompiler
    {
        private readonly HttpClient _http;

        protected abstract string BaseUrl { get; }     // например "http://cpp-runner:8080"
        protected virtual string RunPath  => "/run";
        protected virtual string TestsPath => "/run/tests";

        protected HttpRunnerCompilerBase(HttpClient http)
        {
            _http = http;
        }

        public async Task<CompilerRunResponseDto> CompileAndRunAsync(CompilerRunRequestDto req)
        {
            var body = new
            {
                code = req.Code,
                input = req.Input,
                timeLimitMs = req.TimeLimitMs ?? 2000,
                memoryLimitMb = req.MemoryLimitMb ?? 256
            };

            using var resp = await _http.PostAsJsonAsync($"{BaseUrl}{RunPath}", body);
            resp.EnsureSuccessStatusCode();

            var payload = await resp.Content.ReadFromJsonAsync<RunnerSingleResponse>() 
                          ?? new RunnerSingleResponse();

            // Маппинг на наш DTO
            var dto = new CompilerRunResponseDto
            {
                Status = payload.status ?? "ok",
                ExitCode = payload.exitCode,
                Stdout = payload.stdout,
                Stderr = payload.stderr,
                CompileStderr = payload.compileStderr,
                Message = payload.status switch
                {
                    "compile_error" => "Ошибка компиляции",
                    "runtime_error" => "Ошибка во время выполнения",
                    "time_limit"    => "Превышен лимит времени",
                    _               => null
                }
            };

            return dto;
        }

        public async Task<IList<TestResultDto>> RunTestsAsync(string code, IList<TestCaseDto> testCases,
            int? timeLimitMs = null, int? memoryLimitMb = null)
        {
            var body = new
            {
                code,
                tests = (testCases ?? Array.Empty<TestCaseDto>()).Select(t => new
                {
                    input = t.Input,
                    expectedOutput = t.ExpectedOutput,
                    isHidden = false
                }).ToArray(),
                timeLimitMs = timeLimitMs ?? 2000,
                memoryLimitMb = memoryLimitMb ?? 256
            };

            using var resp = await _http.PostAsJsonAsync($"{BaseUrl}{TestsPath}", body);
            resp.EnsureSuccessStatusCode();

            var payload = await resp.Content.ReadFromJsonAsync<RunnerTestsResponse>()
                          ?? new RunnerTestsResponse { results = new List<RunnerTestItem>() };

            // Переносим в наш формат
            var list = new List<TestResultDto>(payload.results?.Count ?? 0);
            foreach (var r in payload.results ?? Enumerable.Empty<RunnerTestItem>())
            {
                list.Add(new TestResultDto
                {
                    Input = r.input,
                    ExpectedOutput = r.expectedOutput,
                    ActualOutput = r.actualOutput,
                    Passed = r.passed,
                    Status = r.status ?? (r.passed ? "ok" : "runtime_error"),
                    ExitCode = r.exitCode,
                    Stderr = r.stderr,
                    CompileStderr = r.compileStderr,
                    Hidden = r.hidden
                });
            }

            return list;
        }

        #region Вспомогательные record-типы под контракт раннера
        private sealed class RunnerSingleResponse
        {
            public string? status { get; set; }
            public int exitCode { get; set; }
            public string? stdout { get; set; }
            public string? stderr { get; set; }
            public string? compileStderr { get; set; }
        }

        private sealed class RunnerTestsResponse
        {
            public List<RunnerTestItem>? results { get; set; }
        }

        private sealed class RunnerTestItem
        {
            public string? input { get; set; }
            public string? expectedOutput { get; set; }
            public string? actualOutput { get; set; }
            public bool passed { get; set; }
            public string? status { get; set; }
            public int exitCode { get; set; }
            public string? stderr { get; set; }
            public string? compileStderr { get; set; }
            public bool hidden { get; set; }
        }
        #endregion
    }
}
