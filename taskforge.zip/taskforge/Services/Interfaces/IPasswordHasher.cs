﻿namespace taskforge.Services.Interfaces
{
    public interface IPasswordHasher
    {
    }
}
